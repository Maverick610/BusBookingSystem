package BBS;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Bus_info extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bus_info frame = new Bus_info();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bus_info() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 834, 677);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBusInformation = new JLabel("Bus Information");
		lblBusInformation.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBusInformation.setBounds(119, 70, 198, 31);
		contentPane.add(lblBusInformation);
		
		JButton btnShowInfo = new JButton("Show info");
		btnShowInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					
					ResultSet rs =ps.executeQuery("SELECT * FROM `businfo`");
					Container con;
					con=getContentPane();
					con.setLayout(null);
					DefaultTableModel dtm;
					JTable tb;
					String headers[]={"Bus ID","Bus name","Source","Destination","Price"};
					dtm=new DefaultTableModel();
					dtm.setColumnIdentifiers(headers);
					tb=new JTable(dtm);
					JScrollPane jsp= new JScrollPane(tb);
					jsp.setBounds(80,200,700,150);
					con.add(jsp);
					String row[];
					String bid,b,s,d,p;
					
					
					while(rs.next())
					{
						bid=rs.getString("busid");
						//p=rs.getString("pname");
						b=rs.getString("busname");
						s=rs.getString("src");
						d=rs.getString("dest");
						//q=rs.getString("quantity");
						p=rs.getString("price");
						row= new String[] {bid,b,s,d,p};
						dtm.addRow(row);
						
					//System.out.println(id+" "+n+" "+s+" "+d+" "+p+" ");
					}
					//String[] column = {"Bus ID","Busname ","source","Destination","price"};
					//String[] row=
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e)
				{
					
				}
			}
		});
		btnShowInfo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnShowInfo.setBounds(119, 132, 126, 31);
		contentPane.add(btnShowInfo);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Admin_Dashboard obj=new Admin_Dashboard();
				obj.setVisible(true);
			}
		});
		button.setBounds(21, 23, 53, 21);
		contentPane.add(button);
		
		JButton btnAddBus = new JButton("Add Bus");
		btnAddBus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Bus_reg obj=new Bus_reg();
				obj.setVisible(true);
			}
		});
		btnAddBus.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAddBus.setBounds(324, 132, 126, 31);
		contentPane.add(btnAddBus);
	}

}
