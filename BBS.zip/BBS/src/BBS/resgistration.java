package BBS;

import java.awt.BorderLayout;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.TimeZone;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
//import com.mysql.jdbc.PreparedStatement;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import javax.swing.ImageIcon;


public class resgistration extends JFrame {

	private JPanel contentPane;
	private JTextField nameTF;
	private JTextField mobnoTF;
	private JTextField passwordTF;
	public JRadioButton maleRB;
	public JRadioButton femaleRB;
	public JDateChooser dobTF;
	private JTextField emailTF;
	public boolean err=false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					resgistration frame = new resgistration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public resgistration() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 491, 330);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegister = new JLabel("Register");
		lblRegister.setBounds(144, 0, 139, 32);
		lblRegister.setFont(new Font("Arial", Font.PLAIN, 24));
		getContentPane().add(lblRegister);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(288, 0, 144, 32);
		getContentPane().add(label_1);
		
		JLabel lblNmae = new JLabel("Name ");
		lblNmae.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNmae.setBounds(10, 37, 129, 32);
		getContentPane().add(lblNmae);
		
		nameTF = new JTextField();
		nameTF.setBounds(144, 37, 139, 32);
		getContentPane().add(nameTF);
		nameTF.setColumns(10);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(288, 37, 144, 32);
		getContentPane().add(label_2);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblGender.setBounds(10, 74, 129, 32);
		getContentPane().add(lblGender);
		
		maleRB = new JRadioButton("Male");
		maleRB.setFont(new Font("Tahoma", Font.PLAIN, 15));
		maleRB.setBounds(144, 74, 139, 32);
		getContentPane().add(maleRB);
		
		femaleRB = new JRadioButton("Female");
		femaleRB.setFont(new Font("Tahoma", Font.PLAIN, 15));
		femaleRB.setBounds(288, 74, 144, 32);
		getContentPane().add(femaleRB);
		
		ButtonGroup bg= new ButtonGroup();
		bg.add(maleRB);
		bg.add(femaleRB);
		
		
		
		
		JLabel lblDateOfBirth = new JLabel("Email");
		lblDateOfBirth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDateOfBirth.setBounds(10, 111, 129, 32);
		getContentPane().add(lblDateOfBirth);
		
		JLabel lblMobileNumber = new JLabel("Mobile Number");
		lblMobileNumber.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMobileNumber.setBounds(10, 148, 129, 32);
		getContentPane().add(lblMobileNumber);
		
		mobnoTF = new JTextField();
		mobnoTF.setBounds(144, 148, 139, 32);
		getContentPane().add(mobnoTF);
		mobnoTF.setColumns(10);
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(288, 148, 144, 32);
		getContentPane().add(label_4);
		
		JLabel lblEmail = new JLabel("Password");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail.setBounds(10, 185, 129, 32);
		getContentPane().add(lblEmail);
		
		passwordTF = new JTextField();
		passwordTF.setBounds(144, 185, 139, 32);
		getContentPane().add(passwordTF);
		passwordTF.setColumns(10);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(288, 185, 144, 32);
		getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("");
		label_6.setBounds(0, 222, 139, 37);
		getContentPane().add(label_6);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				getRegistered();
				
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnSubmit.setBounds(144, 222, 139, 37);
		getContentPane().add(btnSubmit);
		
		JLabel label_7 = new JLabel("");
		label_7.setBounds(288, 222, 144, 37);
		getContentPane().add(label_7);
		
		//Icon icon = new ImageIcon("icon-back-4.jpg");
		JButton button = new JButton("<-");
		//button.setIcon(new ImageIcon(""));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			dispose();
				
			Login2.main(null);
			//l2.setVisible();
			
			
			
			}
		});
		button.setFont(new Font("Tahoma", Font.PLAIN, 10));
		button.setBounds(10, 11, 55, 21);
		contentPane.add(button);
		
		emailTF = new JTextField();
		emailTF.setBounds(144, 116, 139, 27);
		contentPane.add(emailTF);
		emailTF.setColumns(10);
		
	/*	dobTF = new JDateChooser();
	//	TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		dobTF.setBounds(144, 106, 139, 32);
		contentPane.add(dobTF);*/
		


}
	public void getRegistered()
	{
		try {
			err=false;

			//Class.forName("com.mysql.jdbc.Driver");
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
			Statement ps = conn.createStatement();
			
			
			
			int userid=2;
			String uname=nameTF.getText();
			if(uname.equals(null))
			{
				err=true;
				JOptionPane.showMessageDialog(null,"Enter Name!");

			}
			String gender="";
			if(maleRB.isSelected() ||femaleRB.isSelected())
			{
			if(maleRB.isSelected())
				gender="male";
			else if(femaleRB.isSelected())
				gender="female";
			}
			else 
				{
				JOptionPane.showMessageDialog(null,"Select Gender!");
				err=true;
				}

			String email=emailTF.getText();
			if(email.equals(null))
			{
				err=true;
				JOptionPane.showMessageDialog(null,"Enter Email!");

			}
			String mob_no=mobnoTF.getText();
			if(((mob_no.length())!=10) && mob_no.matches("[0-9]"))
			{
				err=true;
				JOptionPane.showMessageDialog(null,"Enter Proper Mobile number!");

			}
			String password=passwordTF.getText();
			if(uname.equals(null))
			{
				err=true;
				JOptionPane.showMessageDialog(null,"Enter Password!");

			}
			if(err==false)
			{
				
			
				int x=ps.executeUpdate("insert into register(uname,gender,email,mobno,password)values('"+uname+"','"+gender+"','"+email+"','"+mob_no+"','"+password+"');" );

				if(x > 0)
				{
				JOptionPane.showMessageDialog(null,"Registration Completed","Message",JOptionPane.INFORMATION_MESSAGE);
				dispose();
				Login2.main(null);
				}
			}
			else
			JOptionPane.showMessageDialog(null," not successfully ");
			
			
			//ResultSet rs=ps.executeQuery();
			
			
		
				
			
			
			conn.close();
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e,"Login Error",JOptionPane.ERROR_MESSAGE);
		}
		
		}
}