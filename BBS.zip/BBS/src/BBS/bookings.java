package BBS;

import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JOptionPane;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JButton;

//import com.sun.xml.internal.ws.api.server.Container;
import com.toedter.calendar.JDateChooser;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class bookings extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTextField seatsTF;
	private JTextField TotAmtTF;
	int pri=0;
	String res;
	String id,n,s,d,p;
	int q;
	int Total_amount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bookings frame = new bookings();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bookings() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 788, 560);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSource = new JLabel("Source");
		lblSource.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSource.setBounds(109, 89, 86, 21);
		contentPane.add(lblSource);
		
		JComboBox srcCB = new JComboBox();
		srcCB.setFont(new Font("Tahoma", Font.PLAIN, 15));
		srcCB.setBounds(206, 87, 104, 26);
		contentPane.add(srcCB);
		srcCB.addItem("Solapur");
		srcCB.addItem("Mumbai");
		srcCB.addItem("Pune");
		srcCB.addItem("Nanded");
		srcCB.setSelectedItem(null);
		
		JLabel lblDestination = new JLabel("Destination");
		lblDestination.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDestination.setBounds(419, 89, 91, 21);
		contentPane.add(lblDestination);
		
		JComboBox destCB = new JComboBox();
		destCB.setFont(new Font("Tahoma", Font.PLAIN, 15));
		destCB.setBounds(553, 87, 104, 26);
		contentPane.add(destCB);
		destCB.addItem("Solapur");
		destCB.addItem("Mumbai");
		destCB.addItem("Pune");
		destCB.addItem("Nanded");
		destCB.setSelectedItem(null);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
				Statement ps = conn.createStatement();
				
				String src=(String)srcCB.getSelectedItem();
				String dest=(String)destCB.getSelectedItem();
				ResultSet rs =ps.executeQuery("SELECT * FROM `businfo` WHERE src='"+src+"' and dest='"+dest+"'");
				Container con;
				con=getContentPane();
				con.setLayout(null);
				DefaultTableModel dtm;
				JTable tb;
				String headers[]={"Bus ID","Busname ","source","Destination","price"};
				dtm=new DefaultTableModel();
				dtm.setColumnIdentifiers(headers);
				tb=new JTable(dtm);
				JScrollPane jsp= new JScrollPane(tb);
				jsp.setBounds(100,250,600,150);
				con.add(jsp);
				String row[],date;
				
				
				while(rs.next())
				{
					id=rs.getString("busid");
					n=rs.getString("busname");
					s=rs.getString("src");
					d=rs.getString("dest");
					p=rs.getString("price");
					pri=Integer.parseInt(p);
					row= new String[] {id,n,s,d,p};
					dtm.addRow(row);
					
				//System.out.println(id+" "+n+" "+s+" "+d+" "+p+" ");
				}
				//String[] column = {"Bus ID","Busname ","source","Destination","price"};
				//String[] row=
				rs.close();
				ps.close();
				conn.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearch.setBounds(318, 206, 97, 21);
		contentPane.add(btnSearch);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDate.setBounds(419, 155, 86, 14);
		contentPane.add(lblDate);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(553, 155, 104, 26);
		contentPane.add(dateChooser);
		
		JLabel lblEnterNoOf = new JLabel("Enter no of seats");
		lblEnterNoOf.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEnterNoOf.setBounds(109, 432, 146, 21);
		contentPane.add(lblEnterNoOf);
		
		seatsTF = new JTextField();
		seatsTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		seatsTF.setBounds(265, 434, 62, 19);
		contentPane.add(seatsTF);
		seatsTF.setColumns(10);
		
		JButton btnTotalAmount = new JButton("Total Amount");
		btnTotalAmount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				q=Integer.parseInt(seatsTF.getText());
				Total_amount=pri*q;
				res=""+Total_amount;
				TotAmtTF.setText(res);
				
			}
		});
		btnTotalAmount.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnTotalAmount.setBounds(419, 432, 146, 24);
		contentPane.add(btnTotalAmount);
		
		TotAmtTF = new JTextField();
		TotAmtTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		TotAmtTF.setBounds(591, 436, 104, 19);
		contentPane.add(TotAmtTF);
		TotAmtTF.setColumns(10);
		
		JButton btnMakePayment = new JButton("Make Payment");
		btnMakePayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(TotAmtTF.getText()=="")
				{JOptionPane.showMessageDialog(null,"Please select Route","Message",JOptionPane.INFORMATION_MESSAGE);}
				else {
				try {
					//Class.forName("com.mysql.jdbc.Driver");
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					//String pname=pnameTF.getText();
					String bname=new String(n);
					String pname =Login2.un;
					String quantity=""+q;
					String amount=""+Total_amount;
					//String date=dateChooser.toString();
					//System.out.print(date);
					
					String src=(String)srcCB.getSelectedItem();
					String dest=(String)destCB.getSelectedItem();
					
										
					int x=ps.executeUpdate("insert into booking(pname,bname,src,dest,quantity,amount)values('"+pname+"','"+bname+"','"+src+"','"+dest+"','"+quantity+"','"+amount+"');" );

					if(x > 0)
					{
						JOptionPane.showMessageDialog(null,"Payment Successful","Message",JOptionPane.INFORMATION_MESSAGE);
						dispose();
						bookings obj=new bookings();
						obj.setVisible(true);
						
					}
					else
					JOptionPane.showMessageDialog(null," not successfully ");
					conn.close();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e,"Login Error",JOptionPane.ERROR_MESSAGE);
				}
			}
			}
		});
		btnMakePayment.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnMakePayment.setBounds(307, 475, 163, 25);
		contentPane.add(btnMakePayment);
		
		JLabel lblBooking = new JLabel("Booking");
		lblBooking.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblBooking.setBounds(302, 10, 113, 31);
		contentPane.add(lblBooking);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				user_panel b1=new user_panel();
				b1.setVisible(true);
			}
		});
		button.setFont(new Font("Tahoma", Font.PLAIN, 10));
		button.setBounds(32, 10, 52, 21);
		contentPane.add(button);
		
		
		
		
		
	}
}
