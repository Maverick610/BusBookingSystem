package BBS;
import javax.swing.*;
import java.awt.*;
import java.awt.Window.*;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JTextField;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class user_panel extends JFrame {


	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					user_panel frame = new user_panel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public user_panel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnOrder = new JButton("Booking");
		btnOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				bookings b1=new bookings();
				b1.setVisible(true);
				
			}
		});
		btnOrder.setFont(new Font("Arial", Font.PLAIN, 16));
		btnOrder.setBounds(159, 90, 131, 23);
		contentPane.add(btnOrder);
		
		JButton btnNewButton = new JButton("My Bookings");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				userHistory b1=new userHistory();
				b1.setVisible(true);
			}
		});
		btnNewButton.setBounds(159, 143, 131, 23);
		contentPane.add(btnNewButton);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				
				Login2.main(null);
			}
		});
		btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnLogout.setBounds(159, 197, 131, 21);
		contentPane.add(btnLogout);
		
		JLabel lblDashboard = new JLabel("DashBoard");
		lblDashboard.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDashboard.setBounds(52, 25, 199, 23);
		contentPane.add(lblDashboard);
		/*user_panel frame = new user_panel();
		frame.setVisible(true);
		contentPane.setVisible(true);*/
		
	}
}
