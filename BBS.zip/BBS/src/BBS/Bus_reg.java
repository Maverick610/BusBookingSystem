package BBS;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Bus_reg extends JFrame {

	private JPanel contentPane;
	private JTextField nameTF;
	private JTextField srcTF;
	private JTextField destTF;
	private JTextField fareTF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bus_reg frame = new Bus_reg();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bus_reg() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 555, 568);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			dispose();
			Bus_info obj=new Bus_info();
			obj.setVisible(true);
			}
		});
		button.setBounds(10, 26, 55, 21);
		contentPane.add(button);
		
		JLabel lblBusRegistration = new JLabel("Bus Registration");
		lblBusRegistration.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblBusRegistration.setBounds(82, 76, 213, 31);
		contentPane.add(lblBusRegistration);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(82, 138, 92, 31);
		contentPane.add(lblName);
		
		nameTF = new JTextField();
		nameTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		nameTF.setBounds(209, 141, 136, 28);
		contentPane.add(nameTF);
		nameTF.setColumns(10);
		
		JLabel lblSource = new JLabel("Source");
		lblSource.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSource.setBounds(82, 205, 92, 31);
		contentPane.add(lblSource);
		
		srcTF = new JTextField();
		srcTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		srcTF.setBounds(209, 207, 136, 30);
		contentPane.add(srcTF);
		srcTF.setColumns(10);
		
		JLabel lblDestination = new JLabel("Destination");
		lblDestination.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDestination.setBounds(82, 271, 92, 31);
		contentPane.add(lblDestination);
		
		destTF = new JTextField();
		destTF.setBounds(209, 274, 136, 31);
		contentPane.add(destTF);
		destTF.setColumns(10);
		
		JLabel lblFare = new JLabel("Fare");
		lblFare.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblFare.setBounds(82, 345, 92, 21);
		contentPane.add(lblFare);
		
		fareTF = new JTextField();
		fareTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		fareTF.setBounds(209, 341, 136, 31);
		contentPane.add(fareTF);
		fareTF.setColumns(10);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					//Class.forName("com.mysql.jdbc.Driver");
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					String busname=nameTF.getText();
					String src=srcTF.getText();
					String dest=destTF.getText();
					String price=fareTF.getText();
					
					int x=ps.executeUpdate("insert into businfo(busname,src,dest,price)values('"+busname+"','"+src+"','"+dest+"','"+price+"');" );

					if(x > 0)
					{
						JOptionPane.showMessageDialog(null,"Registration Completed","Message",JOptionPane.INFORMATION_MESSAGE);
						dispose();
						Bus_info obj=new Bus_info();
						obj.setVisible(true);
						
					}
					else
					JOptionPane.showMessageDialog(null," not successfully ");
					
					
					//ResultSet rs=ps.executeQuery();
					
					
				
						
					
					
					conn.close();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e,"Login Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnRegister.setBounds(147, 418, 131, 31);
		contentPane.add(btnRegister);
	}
}
