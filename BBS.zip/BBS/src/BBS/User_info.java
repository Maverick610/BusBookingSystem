package BBS;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class User_info extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User_info frame = new User_info();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public User_info() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 834, 661);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserInfo = new JLabel("User Information");
		lblUserInfo.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblUserInfo.setBounds(107, 78, 232, 37);
		contentPane.add(lblUserInfo);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Admin_Dashboard obj=new Admin_Dashboard();
				obj.setVisible(true);
			}
		});
		button.setBounds(23, 26, 51, 21);
		contentPane.add(button);
		
		JButton btnShowInfo = new JButton("Show Info");
		btnShowInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					
					ResultSet rs =ps.executeQuery("SELECT * FROM `register`");
					Container con;
					con=getContentPane();
					con.setLayout(null);
					DefaultTableModel dtm;
					JTable tb;
					String headers[]={"User ID","Name","Gender","Email"};
					dtm=new DefaultTableModel();
					dtm.setColumnIdentifiers(headers);
					tb=new JTable(dtm);
					JScrollPane jsp= new JScrollPane(tb);
					jsp.setBounds(80,200,700,150);
					con.add(jsp);
					String row[];
					String uid,un,g,e;
					
					
					while(rs.next())
					{
						uid=rs.getString("uid");
						//p=rs.getString("pname");
						un=rs.getString("uname");
						g=rs.getString("gender");
						e=rs.getString("email");
						//q=rs.getString("quantity");
						//p=rs.getString("price");
						row= new String[] {uid,un,g,e};
						dtm.addRow(row);
						
					//System.out.println(id+" "+n+" "+s+" "+d+" "+p+" ");
					}
					//String[] column = {"Bus ID","Busname ","source","Destination","price"};
					//String[] row=
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e)
				{
					
				}
			}
		});
		btnShowInfo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnShowInfo.setBounds(303, 139, 137, 27);
		contentPane.add(btnShowInfo);
	}

}
