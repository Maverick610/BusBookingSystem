package BBS;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Admin_login extends JFrame {

	private JPanel contentPane;
	private JTextField nameTF;
	private JPasswordField passwordTF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_login frame = new Admin_login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdminstratorLogin = new JLabel("Adminstrator Login");
		lblAdminstratorLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAdminstratorLogin.setBounds(112, 29, 179, 31);
		contentPane.add(lblAdminstratorLogin);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(66, 108, 98, 22);
		contentPane.add(lblName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPassword.setBounds(66, 163, 98, 22);
		contentPane.add(lblPassword);
		
		nameTF = new JTextField();
		nameTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		nameTF.setBounds(230, 113, 96, 19);
		contentPane.add(nameTF);
		nameTF.setColumns(10);
		
		passwordTF = new JPasswordField();
		passwordTF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		passwordTF.setBounds(230, 168, 96, 19);
		contentPane.add(passwordTF);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String n= nameTF.getText();
				String pw=new String(passwordTF.getPassword());
				if(n.equals("admin") && pw.equals("admin"))
				{
					dispose();
					Admin_Dashboard obj=new Admin_Dashboard();
					obj.setVisible(true);
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLogin.setBounds(150, 217, 85, 21);
		contentPane.add(btnLogin);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					dispose();
				
				Login2.main(null);
			}
		});
		button.setBounds(10, 10, 50, 21);
		contentPane.add(button);
	}
}
