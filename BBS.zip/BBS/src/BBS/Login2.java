package BBS;

import java.awt.Container;
import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class Login2{

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	public static String un;
	String pw;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				Login2 window = new Login2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 361, 295);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAdministratorLogin = new JLabel("Login");
		lblAdministratorLogin.setFont(new Font("Arial", Font.PLAIN, 24));
		lblAdministratorLogin.setBounds(152, 21, 104, 28);
		frame.getContentPane().add(lblAdministratorLogin);
		
		JLabel lblAdminName = new JLabel("Name");
		lblAdminName.setFont(new Font("Arial", Font.PLAIN, 18));
		lblAdminName.setBounds(49, 73, 104, 28);
		frame.getContentPane().add(lblAdminName);
		
		textField = new JTextField();
		textField.setBounds(211, 80, 96, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel passwordField_1 = new JLabel("Password");
		passwordField_1.setFont(new Font("Arial", Font.PLAIN, 18));
		passwordField_1.setBounds(49, 127, 104, 14);
		frame.getContentPane().add(passwordField_1);
		
		JButton btnSubmit = new JButton("Login");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					String un=textField.getText();
					String pw=new String(passwordField.getPassword());
					ResultSet rs =ps.executeQuery("SELECT * FROM `register` WHERE uname='"+un+"' and password='"+pw+"'");
					int c=0;
					while(rs.next())
					{
						c++;
						
					//System.out.println(id+" "+n+" "+s+" "+d+" "+p+" ");
					}
					//String[] column = {"Bus ID","Busname ","source","Destination","price"};
					//String[] row=
					if(c>0)
					{
						Login2.un=un;
						frame.dispose();
						user_panel.main(null);
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Invalid Username or Password ");
					}
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				}

			//getLogin();
			
			
			});
		btnSubmit.setFont(new Font("Arial", Font.PLAIN, 13));
		btnSubmit.setBounds(211, 167, 93, 23);
		frame.getContentPane().add(btnSubmit);
		
		
		
		passwordField = new JPasswordField();
		passwordField.setBounds(211, 127, 96, 19);
		frame.getContentPane().add(passwordField);
		
		JButton btnCreateAccount = new JButton("New? Create an Account");
		btnCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				resgistration obj=new resgistration();
				obj.setVisible(true);
			}
		});
		btnCreateAccount.setFont(new Font("Arial", Font.PLAIN, 13));
		btnCreateAccount.setBounds(49, 211, 255, 21);
		frame.getContentPane().add(btnCreateAccount);
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			frame.dispose();
			Admin_login obj =new Admin_login();
			obj.setVisible(true);
			}
		});
		btnAdminLogin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnAdminLogin.setBounds(49, 169, 119, 21);
		frame.getContentPane().add(btnAdminLogin);
		
		
	}
}
