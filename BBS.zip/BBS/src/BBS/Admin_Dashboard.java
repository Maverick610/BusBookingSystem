package BBS;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Admin_Dashboard extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Dashboard frame = new Admin_Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_Dashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 536, 389);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdministratorDashboard = new JLabel("Administrator Dashboard");
		lblAdministratorDashboard.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblAdministratorDashboard.setBounds(64, 40, 329, 31);
		contentPane.add(lblAdministratorDashboard);
		
		JButton btnUserInfo = new JButton("User Info");
		btnUserInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				User_info obj=new User_info();
				obj.setVisible(true);
			}
		});
		btnUserInfo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUserInfo.setBounds(64, 119, 176, 31);
		contentPane.add(btnUserInfo);
		
		JButton btnBusInfo = new JButton("Bus Info");
		btnBusInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Bus_info obj=new Bus_info();
				obj.setVisible(true);
			}
		});
		btnBusInfo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBusInfo.setBounds(64, 181, 176, 31);
		contentPane.add(btnBusInfo);
		
		JButton btnBookingHistory = new JButton("Booking History");
		btnBookingHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				History b1=new History();
				b1.setVisible(true);
			}
		});
		btnBookingHistory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBookingHistory.setBounds(64, 241, 176, 31);
		contentPane.add(btnBookingHistory);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			dispose();
			Admin_login obj=new Admin_login();
			obj.setVisible(true);			}
		});
		btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLogout.setBounds(64, 302, 176, 31);
		contentPane.add(btnLogout);
	}
}
