package BBS;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class userHistory extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userHistory frame = new userHistory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public userHistory() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 860, 653);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMyBookings = new JLabel("My Bookings");
		lblMyBookings.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblMyBookings.setBounds(104, 78, 170, 31);
		contentPane.add(lblMyBookings);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				user_panel b1=new user_panel();
				b1.setVisible(true);
			}
		});
		button.setBounds(30, 30, 49, 21);
		contentPane.add(button);
		
		JButton btnShowHistory = new JButton("Show History");
		btnShowHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					ResultSet rs =ps.executeQuery("SELECT * FROM `booking` WHERE pname='"+Login2.un+"'");
					Container con;
					con=getContentPane();
					con.setLayout(null);
					DefaultTableModel dtm;
					JTable tb;
					String headers[]={"Bus ID","Bus name","source","Destination","No of seats","Amount"};
					dtm=new DefaultTableModel();
					dtm.setColumnIdentifiers(headers);
					tb=new JTable(dtm);
					JScrollPane jsp= new JScrollPane(tb);
					jsp.setBounds(100,250,600,150);
					con.add(jsp);
					String row[];
					
					String id,n,s,d,q,a;
					while(rs.next())
					{
						id=rs.getString("bid");
						n=rs.getString("bname");
						s=rs.getString("src");
						d=rs.getString("dest");
						q=rs.getString("quantity");
						a=rs.getString("amount");
						row= new String[] {id,n,s,d,q,a};
						dtm.addRow(row);
						
					//System.out.println(id+" "+n+" "+s+" "+d+" "+p+" ");
					}
					//String[] column = {"Bus ID","Busname ","source","Destination","price"};
					//String[] row=
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				
			}
		});
		btnShowHistory.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnShowHistory.setBounds(293, 136, 155, 31);
		contentPane.add(btnShowHistory);
	}
}
