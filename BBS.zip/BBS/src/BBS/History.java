package BBS;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class History extends JFrame {

	private JPanel contentPane;
	String bid,p,b,s,d,q,a;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					History frame = new History();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public History() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 817, 525);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBookingHistory = new JLabel("Booking History");
		lblBookingHistory.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblBookingHistory.setBounds(79, 38, 205, 59);
		contentPane.add(lblBookingHistory);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Admin_Dashboard obj=new Admin_Dashboard();
				obj.setVisible(true);
			}
		});
		button.setBounds(10, 10, 54, 21);
		contentPane.add(button);
		
		
		
		JButton btnShowHistory = new JButton("Show History");
		btnShowHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bbs?serverTimezone=UTC","root","");
					Statement ps = conn.createStatement();
					//String src=(String)srcCB.getSelectedItem();
					//String dest=(String)destCB.getSelectedItem();
					ResultSet rs =ps.executeQuery("SELECT * FROM `booking`");
					Container con;
					con=getContentPane();
					con.setLayout(null);
					DefaultTableModel dtm;
					JTable tb;
					String headers[]={"Bus ID","Passenger name ","Bus name","source","Destination","No of seats","Amount"};
					dtm=new DefaultTableModel();
					dtm.setColumnIdentifiers(headers);
					tb=new JTable(dtm);
					JScrollPane jsp= new JScrollPane(tb);
					jsp.setBounds(80,100,700,150);
					con.add(jsp);
					String row[];
					
					
					while(rs.next())
					{
						bid=rs.getString("bid");
						p=rs.getString("pname");
						b=rs.getString("bname");
						s=rs.getString("src");
						d=rs.getString("dest");
						q=rs.getString("quantity");
						a=rs.getString("amount");
						row= new String[] {bid,p,b,s,d,q,a};
						dtm.addRow(row);
						
					//System.out.println(id+" "+n+" "+s+" "+d+" "+p+" ");
					}
					//String[] column = {"Bus ID","Busname ","source","Destination","price"};
					//String[] row=
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e)
				{
					
				}
				}
			
		});
		btnShowHistory.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnShowHistory.setBounds(395, 63, 156, 21);
		contentPane.add(btnShowHistory);
	}
}
